# -*- coding: utf-8 -*-
"""
Created on Thu Jan 25 16:39:44 2018

@author: D16129083
"""

from math import pi

r = input("Enter the radius of the sphere: ")

volume = 4/3 * pi * float(r) ** 3

print("The volume of a sphere with radius", r, "is", volume)


# Item 8 - The volume of a sphere with radius 5 is 523.5987755982989