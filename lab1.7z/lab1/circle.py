# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from math import pi

r = 12
area = pi * r ** 2
circuference =  2 * pi * r

print("The area of a circle with radius", r, "is", area, 
      ". The circuference of the circle is", circuference)

# Item 1 - An IDE is a software hat allows you to write and compile code.

# Item 2 - We created all he folders/directories o differenciate all the programs and exercises.

# Item 3 - It is a good habit to have names that makes sense, because i helps other developers to 
#           understand the code.

# Item 4 - The Area of the circle is 452.3893421169302

# Item 5 - The circuference of the circle is 

# Item 6 - I changed the type of the variable radius, the console prints out the TypeError: 
#           unsupported operand type(s) for ** or pow(): 'str' and 'int'
#           Note: If I remove the radius variable after the code has already being running, 
#           the code still runs fine.




