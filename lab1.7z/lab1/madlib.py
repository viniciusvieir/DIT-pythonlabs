# -*- coding: utf-8 -*-
"""
Created on Thu Jan 25 16:35:38 2018

@author: D16129083
"""

adjective = input("Enter an adjective: ")
noun = input("Enter a noun: ")
verb = input("Enter a verb: ")
adverb = input("Enter an adverb: ")

print("A", adjective, noun, "should never", verb, adverb)
print("A", adjective, noun, "cannot", verb, adverb)

# Item 7 - 