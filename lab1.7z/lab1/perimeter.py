# -*- coding: utf-8 -*-
"""
Created on Thu Jan 25 17:10:29 2018

@author: D16129083
"""

width = input("Type the width of the rectangle: ")
lenth = input("Type the lenth of the rectangle: ")

area = float(width) * float(lenth)

print("The area of the rectangle is", area)