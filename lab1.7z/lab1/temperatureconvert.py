# -*- coding: utf-8 -*-
"""
Created on Thu Jan 25 17:07:43 2018

@author: D16129083
"""

celsius = input("The the temperature in Celsius: ")

fahrenheit = float(celsius) * 9/5 + 32

print(celsius, "celsius is equivalent to", fahrenheit, "fahrenheit")