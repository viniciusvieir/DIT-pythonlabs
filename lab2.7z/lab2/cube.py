# -*- coding: utf-8 -*-
"""
Created on Mon Jan 29 15:18:19 2018

@author: D16129083
"""

"""
EXERCISE 2
    The value that surface area and volume are equals is 6.
"""

width = input('Type the width of the cube: ')

volume = float(width) ** 3
surface_area = 6 * float(width) ** 2

print('The volume of the cube is', volume)
print('The surface area of the cube is', surface_area)

